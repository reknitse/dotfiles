DejaVu Sans Mono for Powerline
==============================

:Font creator: Roy Y.T. Chen
:Source: http://dejavu-fonts.org/wiki/Main_Page
:Patched by: `dbrgn <https://github.com/dbrgn>`_

# The Fuck

[The Fuck](https://github.com/nvbn/thefuck) plugin — magnificent app which corrects your previous console command.

## Usage
Press `ESC` twice to correct previous console command.

## Notes
`Esc`-`Esc` key binding conflicts with [sudo](https://github.com/robbyrussell/oh-my-zsh/tree/master/plugins/sudo) plugin.
